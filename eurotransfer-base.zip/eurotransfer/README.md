# EuroTransfer — base non opérationnelle

Interface responsive pour préparer un transfert carte vers IBAN. Aucun numéro de carte ni CVC n'est demandé ou stocké.

## Exécution

`npm install` puis `npm start` et ouvrir http://localhost:3000.

## Avant activation réelle

1. Contrat PSP agréé autorisant explicitement le modèle card pay-in → wallet → payout vers un bénéficiaire tiers.
2. Vérification d'identité KYC/KYB, AML, sanctions, consentement et authentification forte.
3. Paiement hébergé par le PSP, jamais de collecte de PAN/CVC sur le serveur.
4. Webhooks authentifiés, idempotence, journal comptable, réconciliation, remboursements, chargebacks et contrôles de fraude.
5. Enregistrement du bénéficiaire, validation IBAN et vérification du bénéficiaire selon les règles applicables.
6. Authentification des utilisateurs, anti-CSRF, rate limiting, surveillance et politique de confidentialité.

Le backend retourne volontairement 503 tant qu'un prestataire n'est pas intégré.
