// Base sécurisée : aucun paiement réel avant intégration contractuelle d'un PSP.
const express = require('express');
const path = require('path');
const app = express();
app.disable('x-powered-by');
app.use(express.json({limit:'8kb'}));
app.use(express.static(path.join(__dirname)));
app.post('/api/transfer-intents', (req,res)=>{
  const {name,iban,amount}=req.body||{};
  if(typeof name!=='string'||typeof iban!=='string'||typeof amount!=='number'||!Number.isFinite(amount)||amount<0.01||amount>10000)return res.status(400).json({error:'Données invalides'});
  // TODO: authentifier l'utilisateur, vérifier IBAN, limites, conformité et bénéficiaire.
  // TODO: créer une session de paiement hébergée chez le PSP et retourner son URL.
  // TODO: vérifier les webhooks signés; déclencher le payout autorisé une seule fois.
  return res.status(503).json({error:'Paiements réels non activés : contrat PSP et intégration nécessaires.'});
});
app.listen(process.env.PORT||3000,()=>console.log('EuroTransfer prêt'));
